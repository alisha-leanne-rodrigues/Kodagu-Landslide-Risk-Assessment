# Kodagu integrated landslide-susceptibility dataset

One row = one real 30 m pixel (EPSG:7755). Label, terrain, land cover, hydrology and rainfall come from
`Kodagu_Landslide_Dataset`; **soil** (12 cols) from SoilGrids 2.0; **roads** (4 cols) from OpenStreetMap. Columns are documented in `data_dictionary.csv`.

## Files
- `kodagu_integrated_core.csv` - RECOMMENDED (7,277 rows: 2,292 landslide / 4,985 non-landslide)
- `integrated_train.csv / integrated_validation.csv / integrated_test.csv` - spatial split (500 m buffer), same as source
- `kodagu_integrated_all.csv` - core + 7,427 far negatives (map calibration only, never for test scores)

## How the layers were joined
- Roads: the four 30 m rasters are on the same grid as the landslide table, so values were read at each pixel's x/y.
- Soil: each pixel's lon/lat was reprojected to Interrupted Goode Homolosine and the 250 m cell value read (nearest cell, no resampling), then converted (pH/10, clay and sand g/kg /10 -> %, SOC dg/kg /10 -> g/kg).
- Gaps: 104 rows fell on empty SoilGrids cells -> copied from the nearest valid cell (<= 750 m), flag `soil_filled_nearest`.
  20 rows lay outside the road-raster footprint -> distance/density computed from the 5 km-buffered OSM vectors, flag `road_filled_from_vector`.
  No missing values remain in any new column.

## Cautions
1. Never train on `row, col, x, y, lon, lat` or `dist_to_landslide_m`. Split by `fold` / `suggested_split` (scar-grouped), never randomly.
2. Soil is 250 m, modelled (not surveyed) and spatially smooth. Sand % correlates about -0.9 with elevation, so it can act as a location/elevation proxy. Test with and without it.
3. The 5 rainfall columns are ~98-100 % correlated and are a location proxy; use at most one. Soil layers within a property are also strongly correlated across depths (r ~0.8-0.9).
4. OSM roads are a 2026 snapshot, labels are Aug 2018: some roads may post-date the event. Road width, cut-slope and surface are mostly unmapped.
5. All labels are in north/north-west Kodagu; predictions elsewhere are extrapolation.

## Licences / citation
Landslide labels: Arpitha et al. 2024 (CC-BY-SA-4.0). Soil: Poggio et al. 2021, SOIL 7:217-240 (ISRIC SoilGrids). Roads: (c) OpenStreetMap contributors, ODbL 1.0.
The combined table is derived from these, so keep attribution and share under compatible terms (CC-BY-SA-4.0 / ODbL).
